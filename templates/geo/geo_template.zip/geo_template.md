---
author:
  - name: Your Name
    affiliation: Your affiliation
    orcid: Your ORCid
  - name: Your co-author's name
    affiliation: Their affiliation
    orcid: Their ORCid
title: The title of your publication
abstract:
  A concise description of your publication
keywords: [lorem, ipsum, dolor, sit, amet]
date: 2017-01-13
license: cc-by
---